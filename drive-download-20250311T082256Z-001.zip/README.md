# Face-Detection

Package Required :
1.) cvzone 1.4.1 (include opencv and numpy)
2.) pyfirmata
